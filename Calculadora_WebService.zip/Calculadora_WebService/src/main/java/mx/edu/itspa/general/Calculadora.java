package mx.edu.itspa.general;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

@WebService(serviceName = "Calculadora")
public class Calculadora {
    
    @WebMethod(operationName = "suma")
    public double suma(@WebParam(name = "x") double x, @WebParam(name = "y") double y) {
        
        return x+y;
    }
    

    @WebMethod(operationName = "resta")
    public double resta(@WebParam(name = "x") double x, @WebParam(name = "y") double y) {
        
        return x-y;
    }
    

    @WebMethod(operationName = "multiplicacion")
    public double multiplicacion(@WebParam(name = "x") double x, @WebParam(name = "y") double y) {
        
        return x*y;
    }
    

    @WebMethod(operationName = "division")
    public double division(@WebParam(name = "x") double x, @WebParam(name = "y") double y) {
        
        return x/y;
    }
    
}
