package mx.edu.itspa.general;



import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import mx.edu.itspa.general.*;

@WebServlet(name = "ControladorWebService", urlPatterns = {"/ControladorWebService"})
public class ControladorWebService extends HttpServlet {

    Calculadora operacion = null;

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        String accion = request.getParameter("accion");
        
        Double x = Double.parseDouble(request.getParameter("x"));
        Double y = Double.parseDouble(request.getParameter("y"));
        
        
        if(accion.equals("Sumar")){   
            request.setAttribute("Resultado", "La suma de " + x + " y " + y + " es: " + suma(x, y) + ".");
            request.getRequestDispatcher("index.jsp").forward(request, response);   
        }  
        
        if(accion.equals("Restar")){   
            request.setAttribute("Resultado", "La resta de " + x + " y " + y + " es: " + resta(x, y) + ".");
            request.getRequestDispatcher("index.jsp").forward(request, response);   
        }  
        
        if(accion.equals("Multiplicar")){   
            request.setAttribute("Resultado", "La multiplicacion de " + x + " y " + y + " es: " + multiplicacion(x, y) + ".");
            request.getRequestDispatcher("index.jsp").forward(request, response);   
        }  
        
        if(accion.equals("Dividir")){   
            request.setAttribute("Resultado", "La division de " + x + " y " + y + " es: " + division(x, y) + ".");
            request.getRequestDispatcher("index.jsp").forward(request, response);   
        }  
        
        else {
            request.getRequestDispatcher("index.jsp").forward(request, response);   
        }
        
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    public double suma(double x, double y){
        Calculadora_Service cs = new Calculadora_Service();
        Calculadora Port = cs.getCalculadoraPort();
        
        return Port.suma(x, y);
    }
         
    public double resta(double x, double y){
        Calculadora_Service cs = new Calculadora_Service();
        Calculadora Port = cs.getCalculadoraPort();
        
        return Port.resta(x, y);
    }
         
    public double multiplicacion(double x, double y){
        Calculadora_Service cs = new Calculadora_Service();
        Calculadora Port = cs.getCalculadoraPort();
        
        return Port.multiplicacion(x, y);
    }
         
    public double division(double x, double y){
        Calculadora_Service cs = new Calculadora_Service();
        Calculadora Port = cs.getCalculadoraPort();
        
        return Port.division(x, y);
    }
    
}
